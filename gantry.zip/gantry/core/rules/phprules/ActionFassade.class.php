<?php
class ActionFassade
{

}

?>